Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "957d0f23c40513a9b82d583e8428d7c85d1710c5"
Public Const MM_WORK_TREE As String = "fe3d79dedfeb282e5e80f8ebf0a345b927811b35"
Public Const MM_TOOL_VERSION As String = "0.1.0"
