Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "43274914149a67c3f076e5322e86060e3b1d1cc1"
Public Const MM_WORK_TREE As String = "190494ac751fff8b51b925413f46b426f4e5eb25"
Public Const MM_TOOL_VERSION As String = "0.1.0"
