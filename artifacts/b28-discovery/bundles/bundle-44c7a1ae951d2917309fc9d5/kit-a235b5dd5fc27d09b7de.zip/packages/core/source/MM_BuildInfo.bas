Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "982ce2bd11ad971b9614e12d38a6830b5a7789ba"
Public Const MM_WORK_TREE As String = "b4e423ac2faccbcc0c11e65e8a10917ece862c88"
Public Const MM_TOOL_VERSION As String = "0.1.0"
