Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "7477c28759fcb6a7188caba8dc5386264b90fe2b"
Public Const MM_WORK_TREE As String = "c1642f2bdccee8f7ca2bd3d0bc6b5d06dfb524ae"
Public Const MM_TOOL_VERSION As String = "0.1.0"
