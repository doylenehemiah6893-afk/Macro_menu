Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "0b28548e5ebe1ee6f5c174122d56c92c2e6005ed"
Public Const MM_WORK_TREE As String = "cbcac84169c75133fdb2de1b984ef62645edd5b7"
Public Const MM_TOOL_VERSION As String = "0.1.0"
