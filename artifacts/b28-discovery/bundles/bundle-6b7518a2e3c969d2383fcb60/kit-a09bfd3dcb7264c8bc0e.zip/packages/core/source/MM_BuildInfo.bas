Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "f2c9d8d8cd1e448444dd43aadb5e4fa57b5c86d0"
Public Const MM_WORK_TREE As String = "6d9e36b85b5f8d1294c9934dff625497bc2441c9"
Public Const MM_TOOL_VERSION As String = "0.1.0"
