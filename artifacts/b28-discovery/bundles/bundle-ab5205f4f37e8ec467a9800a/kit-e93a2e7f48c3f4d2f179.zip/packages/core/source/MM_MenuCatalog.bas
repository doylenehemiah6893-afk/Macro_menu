Attribute VB_Name = "MM_MenuCatalog"
Option Explicit

Public Function MM_ToolIds() As Variant
    MM_ToolIds = Array("core.document-summary", "core.healthcheck")
End Function

Public Function MM_ToolCaptions() As Variant
    MM_ToolCaptions = Array("Document Summary", "Health Check")
End Function

Public Function MM_ToolTooltips() As Variant
    MM_ToolTooltips = Array("Summarize the active document without changing CATIA state.", "Report Core runtime readiness without changing CATIA state.")
End Function

Public Function MM_ToolGroupIds() As Variant
    MM_ToolGroupIds = Array("core.general", "core.general")
End Function

Public Function MM_ToolGroupCaptions() As Variant
    MM_ToolGroupCaptions = Array("Core", "Core")
End Function

Public Function MM_ToolControlNames() As Variant
    MM_ToolControlNames = Array("btn_core_document_summary_ad68681f", "btn_core_healthcheck_935fb1b1")
End Function

Public Function MM_ToolPageNames() As Variant
    MM_ToolPageNames = Array("pg_core_general_635cb7db", "pg_core_general_635cb7db")
End Function
