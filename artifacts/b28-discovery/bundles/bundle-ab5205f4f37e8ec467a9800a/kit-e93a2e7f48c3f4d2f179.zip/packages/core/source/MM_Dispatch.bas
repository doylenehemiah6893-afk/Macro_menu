Attribute VB_Name = "MM_Dispatch"
Option Explicit

Public Function Core_Invoke(ByVal request As Variant) As Variant
    Dim requestId As String
    Dim commandId As String
    Dim context As C_MMContext
    Dim result As C_MMResult
    Dim buildingResponse As Boolean
    On Error GoTo Fail
    If Not MM_Protocol.TryParseRequest(request, requestId, commandId, context, result) Then GoTo CleanExit
    Select Case commandId
        Case "core.document-summary"
            Set result = MM_DocumentSummary.RunDocumentSummary(context)
        Case "core.healthcheck"
            Set result = MM_HealthCheck.RunHealthCheck(context)
        Case Else
            Set result = MM_Error.UnknownCommand(commandId)
    End Select
CleanExit:
    buildingResponse = True
    Core_Invoke = MM_Protocol.BuildResponse(requestId, result)
    Exit Function
Fail:
    If buildingResponse Then Exit Function
    Set result = MM_Error.InternalError(Err.Number)
    Resume CleanExit
End Function
