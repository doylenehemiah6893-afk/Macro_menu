Attribute VB_Name = "MM_BuildInfo"
Option Explicit

Public Const MM_PROTOCOL_VERSION As String = "MM/1"
Public Const MM_MANIFEST_DIGEST As String = "d8fe08827f1babf7282e6177e6d2e9d8c9c6cdc1f201e86812e37504986f0522"
Public Const MM_WORK_COMMIT As String = "68022541bf8cacd1db012128daf4cdef1048af8d"
Public Const MM_WORK_TREE As String = "405f24751ddabecced9b547680e6dbdefdeb80be"
Public Const MM_TOOL_VERSION As String = "0.1.0"
